package com.webstore.entities;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "payment", schema = "lojavirtual")
public class PaymentEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "payment_id")
    private long paymentId;
    @Basic
    @Column(name = "payment_date")
    private String paymentDate;
    @OneToMany(mappedBy = "payment", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<CourseEntity> courses;
    @OneToOne(mappedBy = "payment")
    private ClientEntity client;

    public PaymentEntity(String paymentDate, List<CourseEntity> courses) {
        this.paymentDate = paymentDate;
        this.courses = courses;
    }

    public PaymentEntity(){}

    public ClientEntity getClient() {
        return client;
    }
    public void setClient(ClientEntity client) {
        this.client = client;
    }
    public List<CourseEntity> getCourses() {
        return courses;
    }
    public void setCourse(CourseEntity course) {
        this.courses.add(course);
    }
    public void setCourses(List<CourseEntity> courses){
        this.courses = courses;
    }
    public long getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(long paymentId) {
        this.paymentId = paymentId;
    }
    public String getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    @Override
    public String toString() {
        return "PaymentEntity{" +
                "paymentId=" + paymentId +
                ", paymentDate='" + paymentDate + '\'' +
                '}';
    }
}
