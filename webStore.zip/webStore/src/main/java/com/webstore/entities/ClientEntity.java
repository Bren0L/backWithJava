package com.webstore.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "client", schema = "lojavirtual")
public class ClientEntity implements Serializable {
    public ClientEntity(String clientName, String clientCpf, String cadDate, String clientEmail, String clientPassword, String clientAddress) {
        this.clientName = clientName;
        this.clientCpf = clientCpf;
        this.regDate = cadDate;
        this.clientEmail = clientEmail;
        this.clientPassword = clientPassword;
        this.clientAddress = clientAddress;
    }
    public ClientEntity(){}


    @Id
    @Column(name = "matricula")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long registration;
    @Basic
    @Column(name = "client_name")
    private String clientName;
    @Basic
    @Column(name = "client_cpf")
    private String clientCpf;
    @Basic
    @Column(name = "cad_date")
    private String regDate;
    @Basic
    @Column(name = "client_email")
    private String clientEmail;
    @Basic
    @Column(name = "client_password")
    private String clientPassword;
    @Basic
    @Column(name = "client_address")
    private String clientAddress;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "payment_id", referencedColumnName = "payment_id")
    private PaymentEntity payment;

    public PaymentEntity getPayment() {
        return payment;
    }
    public void setPayment(PaymentEntity payment) {
        this.payment = payment;
    }
    public long getRegistration() {
        return registration;
    }
    public void setRegistration(long registration) {
        this.registration = registration;
    }
    public String getClientName() {
        return clientName;
    }
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
    public String getClientCpf() {
        return clientCpf;
    }
    public void setClientCpf(String clientCpf) {
        this.clientCpf = clientCpf;
    }
    public String getRegDate() {
        return regDate;
    }
    public void setRegDate(String regDate) {
        this.regDate = regDate;
    }
    public String getClientEmail() {
        return clientEmail;
    }
    public void setClientEmail(String clientEmail) {
        this.clientEmail = clientEmail;
    }
    public String getClientPassword() {
        return clientPassword;
    }
    public void setClientPassword(String clientPassword) {
        this.clientPassword = clientPassword;
    }
    public String getClientAddress() {
        return clientAddress;
    }
    public void setClientAddress(String clientAddress) {
        this.clientAddress = clientAddress;
    }

    @Override
    public String toString() {
        return "ClientEntity{" +
                "registration=" + registration +
                ", clientName='" + clientName + '\'' +
                ", clientCpf='" + clientCpf + '\'' +
                ", regDate='" + regDate + '\'' +
                ", clientEmail='" + clientEmail + '\'' +
                ", clientPassword='" + clientPassword + '\'' +
                ", clientAddress='" + clientAddress + '\'' +
                ", payment=" + payment +
                '}';
    }
}
