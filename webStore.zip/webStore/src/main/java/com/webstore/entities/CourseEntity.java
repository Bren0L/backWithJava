package com.webstore.entities;

import net.bytebuddy.build.ToStringPlugin;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "course", schema = "lojavirtual")
public class CourseEntity implements Serializable {
    public CourseEntity(String courseName, double coursePrice, String courseUrl, String courseDescription) {
        this.courseName = courseName;
        this.coursePrice = coursePrice;
        this.courseUrl = courseUrl;
        this.courseDescription = courseDescription;
    }
    public CourseEntity(){}

    @Id
    @Column(name = "course_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long courseId;
    @Basic
    @Column(name = "course_name")
    private String courseName;
    @Basic
    @Column(name = "course_price")
    private double coursePrice;
    @Basic
    @Column(name = "course_url")
    private String courseUrl;
    @Basic
    @Column(name = "course_description")
    private String courseDescription;
    @ToStringPlugin.Exclude
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "course_payment_id")
    private PaymentEntity payment;

    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }

    public String getCourseUrl() {
        return courseUrl;
    }

    public void setCourseUrl(String courseUrl) {
        this.courseUrl = courseUrl;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    @Override
    public String toString() {
        return "CourseEntity{" +
                "courseId=" + courseId +
                ", courseName='" + courseName + '\'' +
                ", coursePrice=" + coursePrice +
                ", courseUrl='" + courseUrl + '\'' +
                ", courseDescription='" + courseDescription + '\'' +
                ", payment=" + payment +
                '}';
    }
}
