package com.webstore.controller;

import com.webstore.entities.ClientEntity;
import com.webstore.services.ClientNotFoundException;
import com.webstore.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class ClientController {
    @Autowired
    private ClientService service;

    @GetMapping("/clients")
    public String getClients(Model model){
        List<ClientEntity> clients = service.getClients();
        model.addAttribute("listClients", clients);
        return "clients";
    }

    @GetMapping("/clients/new")
    public String newClient(Model model){
        model.addAttribute("client", new ClientEntity());
        model.addAttribute("title", "Add New Client");
        return "client_form";
    }

    @GetMapping("/clients/login")
    public String login(Model model){
        model.addAttribute("client", new ClientEntity());
        return "clients";
    }

    @RequestMapping(value = "/clients/login/verify", method = RequestMethod.POST)
    public String verify(@ModelAttribute ClientEntity clientEntity, ClientEntity client, RedirectAttributes ra, Model model){
        if(service.verifyClient(client)){
            ra.addFlashAttribute("getClient", service.getClientByEmail(client.getClientEmail()));
            return "redirect:/course";
        }
        ra.addFlashAttribute("message", "Login or password incorrect");
        return "redirect:/clients/login";
    }

    @PostMapping("/clients/save")
    public String saveClient(ClientEntity client, RedirectAttributes ra){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        client.setRegDate(LocalDate.now().format(formatter));
        service.save(client);
        ra.addFlashAttribute("message", "Client edited successfully");
        return "redirect:/clients";
    }

    @GetMapping("/clients/edit/{id}")
    public String updateClient(@PathVariable("id") long id, Model model, RedirectAttributes ra){
        model.addAttribute("title", "Edt User With Register="+id);
        try {
            ClientEntity client = service.getClient(id);
            model.addAttribute("client", client);
            return "client_form";
        } catch (ClientNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
            return "redirect:/clients";
        }
    }

    @GetMapping("/clients/delete/{id}")
    public String deleteClient(@PathVariable("id") long id, RedirectAttributes ra){
        try {
            service.deleteClient(id);
        } catch (ClientNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/clients";
    }

}
