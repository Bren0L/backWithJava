package com.webstore.controller;

import com.webstore.entities.ClientEntity;
import com.webstore.entities.CourseEntity;
import com.webstore.entities.PaymentEntity;
import com.webstore.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Controller
public class CourseController {
    private ClientEntity clientEntity;
    @Autowired
    private CourseService service;
    @Autowired
    private ClientService clientService;
    @Autowired
    private PaymentService paymentService;

    @RequestMapping(value = "/course", method = RequestMethod.GET)
    public String getCourse(@ModelAttribute("getClient") ClientEntity client, Model model){
        clientEntity = client;
        List<CourseEntity> courses = service.getAllCourses();
        model.addAttribute("courseList", courses);
        return "courses_page";
    }

    @RequestMapping(value = "/courses/getCourse/{id}", method = RequestMethod.GET)
    public String getCourse(@PathVariable("id") long id, RedirectAttributes ra, Model model){
        try {
            CourseEntity course = service.getCourse(id);
            PaymentEntity payment = paymentService.getPaymentById(clientEntity.getPayment().getPaymentId());
            payment.setCourse(service.getCourse(id));
            if(clientEntity.getPayment() == null){
                clientEntity.setPayment(new PaymentEntity());
            }
            if(clientEntity.getPayment().getCourses() == null){
                clientEntity.getPayment().setCourses(new ArrayList<>());
            }
            model.addAttribute("course", course);
            clientEntity.getPayment().setCourses(new ArrayList<>(Collections.singletonList(service.getCourse(id))));
            paymentService.save(payment);
            return "courses_page";
        } catch (CourseNotFoundException | PaymentNotFoundException e) {
            ra.addFlashAttribute("message", "Erro: "+e.getMessage());
            return "redirect:/course";
        }
    }

    @GetMapping("coursesFromClient")
    public String getCoursesfromClient(Model model){
        //model.addAttribute("course", client1);
        return "courses_client";
    }

    @GetMapping("/courses/delete/{id}")
    public String deleteCourse(@PathVariable("id") long id, RedirectAttributes ra){
        try {
            service.deleteCourse(id);
        } catch (CourseNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/course";
    }
}
